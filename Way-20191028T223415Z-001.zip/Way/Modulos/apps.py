from django.apps import AppConfig


class ModulosConfig(AppConfig):
    name = 'Modulos'
